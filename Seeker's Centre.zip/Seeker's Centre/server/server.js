const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const path = require('path'); // Import path module
const User = require('./models/user'); // Ensure the path is correct
const fs = require('fs');
const multer = require('multer');
const upload = multer();

const app = express();
const PORT = process.env.PORT || 5000;



// Middleware
app.use(express.json());
app.use(cors()); // Use this if you have frontend running on a different port
app.use(express.urlencoded({ extended: true }));


// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/seekers-centre');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});


app.post('/api/register', async (req, res) => {
    const { username, email, password } = req.body;

    // Validate input
    if (!username || !email || !password) {
        return res.status(400).json({ error: 'Please provide username, email, and password' });
    }

    try {
        // Check if the user already exists
        let existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists with this email' });
        }

        // Create a new user instance
        const newUser = new User({ username, email, password });

        // Save the user to the database
        const savedUser = await newUser.save();

        // Return success response
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        // Handle registration errors
        res.status(500).json({ error: 'Error registering user: ' + error.message });
    }
});



app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;

    console.log(`Login attempt for email: ${email}`);

    // Validate input
    if (!email || !password) {
        console.log('Missing email or password');
        return res.status(400).json({ error: 'Please provide email and password' });
    }

    try {
        // Find the user by email
        const user = await User.findOne({ email });
        if (!user) {
            console.log('User not found');
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        console.log(`User found: ${user.email}`);

        // Compare the provided password with the stored hash
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            console.log('Password does not match');
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        console.log('Password matches');

        // Return success response
        res.status(200).json({ message: 'User logged in successfully' });
    } catch (error) {
        // Handle login errors
        console.error('Error logging in:', error.message);
        res.status(500).json({ error: 'Error logging in: ' + error.message });
    }
});

app.post('/api/logout', (req, res) => {
    // Clear session or token here if you are using them
    // For example, if using session-based authentication:
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ error: 'Error logging out: ' + err.message });
        }
        res.status(200).json({ message: 'Logged out successfully' });
    });
});
app.post('/upload-job', upload.none(), (req, res) => {
    const { type, position, company, description, link } = req.body;

    // Log the received data
    console.log('Received data:', req.body);

    if (!type || !position || !company || !description || !link) {
        console.error('Missing fields:', { type, position, company, description, link });
        return res.status(400).send('All fields are required.');
    }

    const filename = `${position.replace(/\s+/g, '_')}_at_${company.replace(/\s+/g, '_')}.html`;

    const jobDescriptionHTML = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${position} at ${company}</title>
                <link rel="stylesheet" href="styles.css">
            </head>
            <body>
                <header>
                <div class="logo-search-container"> <a href="index.html"><img src="logo.png" alt="Logo" class="logo"></a></div>
                    <h1>${position} at ${company}</h1>
                    <div class="auth-buttons">
                        <img src="profile-icon.png" alt="Profile" class="profile-icon" style="height: 40px; width: 40px;">
                        <div id="profileMenu" class="profile-menu-content">
                            <a href="">Applied Jobs</a>
                            <a href="../index.html" onclick="signOut()">Sign Out</a>
                        </div>
                    </div>
                    
                </header>
                <main>
                <div class="main-content">
                    <section>
                        <h2>Job Description</h2>
                        <p>${description}</p>
                        <div class=auth-buttons>
                            <a href="${link}"class="apply" target="_blank">Apply Here</a>
                        </div>
                        
                    </section>
                    </div>
                </main>
            </body>
            </html>
                    `;

       
        const jobDescriptionPath = path.join('D:\\Seeker\'s Centre\\public\\jobs', filename);

        fs.writeFile(jobDescriptionPath, jobDescriptionHTML, (err) => {
            if (err) {
                return res.status(500).send('Server error, please try again later.');
            }
    
            const jobsFilePath1 = 'D:\\Seeker\'s Centre\\public\\jobs.html';
            const internshipsFilePath1 = 'D:\\Seeker\'s Centre\\public\\internships.html';
            const jobsFilePath2 = 'D:\\Seeker\'s Centre\\public\\logged_in\\jobs.html';
            const internshipsFilePath2 = 'D:\\Seeker\'s Centre\\public\\logged_in\\internships.html';
    
            const listFilePath1 = type === 'job' ? jobsFilePath1 : internshipsFilePath1;
            const listFilePath2 = type === 'job' ? jobsFilePath2 : internshipsFilePath2;
    
            // Read and update the first file
            fs.readFile(listFilePath1, 'utf8', (err, data1) => {
                if (err) {
                    return res.status(500).send('Server error, please try again later.');
                }
    
                const newListingHTML1 = `
                <div class="${type === 'job' ? 'job-listing' : 'internship-listing'}">
                    <a href="login.html">${position} @ ${company}</a>
                    <p>Just now</p>
                </div>
                            `;
    
                const updatedHTML1 = data1.replace('<div></div>', `<div></div> ${newListingHTML1}`);
    
                fs.writeFile(listFilePath1, updatedHTML1, 'utf8', (err) => {
                    if (err) {
                        return res.status(500).send('Server error, please try again later.');
                    }
    
                    // Read and update the second file
                    fs.readFile(listFilePath2, 'utf8', (err, data2) => {
                        if (err) {
                            return res.status(500).send('Server error, please try again later.');
                        }
    
                        const newListingHTML2 = `
                        <div class="${type === 'job' ? 'job-listing' : 'internship-listing'}">
                            <a href="../jobs/${filename}">${position} @ ${company}</a>
                            <p>Just now</p>
                        </div>
                        `;
    
                        const updatedHTML2 = data2.replace('<div></div>', `<div></div> ${newListingHTML2}`);
    
                        fs.writeFile(listFilePath2, updatedHTML2, 'utf8', (err) => {
                            if (err) {
                                return res.status(500).send('Server error, please try again later.');
                            }
    
                            
                        });
                        const adminFilePath = 'D:\\Seeker\'s Centre\\public\\logged_in\\admin.html';
                        fs.readFile(adminFilePath, 'utf8', (err, data3) => {
                            if (err) {
                                return res.status(500).send('Server error, please try again later.');
                            }
                            const newListingHTML3 = `
                            <div class="${type === 'job' ? 'job-listing' : 'internship-listing'}">
                                <a href="../jobs/${filename}">${position} @ ${company}</a>
                                <button type="submit">Delete Job</button>
                                <p>Just now</p>
                            </div>
                            `;
                            const updatedHTML3 = data3.replace('<div></div>', `<div></div> ${newListingHTML3}`);
                            fs.writeFile(adminFilePath, updatedHTML3, 'utf8', (err) => {
                                if (err) {
                                    return res.status(500).send('Server error, please try again later.');
                                }
        
                                res.send('Job uploaded and all pages updated successfully.');
                            });
                            
                        });
                    });
                });
            });
        });
    });
    


        
// Serve the admin form from the logged_in folder
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'logged_in', 'admin.html'));
});
// Serve index.html for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});
// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});


