document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const jobTitle = urlParams.get('title');
    const jobDescription = urlParams.get('description');

    document.getElementById('job-title').textContent = jobTitle;
    document.getElementById('job-description').textContent = jobDescription;
});
