document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    const loginForm = document.getElementById('loginForm');

    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(registerForm);
            const data = Object.fromEntries(formData);
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            alert(result.message || result.error);
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(loginForm);
            const data = Object.fromEntries(formData);
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            alert(result.message || result.error);
        });
    }
    
});

function signOut() {
    // Add your sign-out logic here
    // For example, clearing session storage or cookies and redirecting to login page
    fetch('/api/logout', { method: 'POST' }) // Ensure you have an endpoint for logging out
        .then(response => {
            if (response.ok) {
                window.location.href = '/login.html'; // Redirect to login page after sign-out
            }
        });
    }

// scripts.js
function signOut() {
    // You can clear any stored data or perform any logout logic here
    console.log("User signed out");

    // Redirect to the login page
    window.location.href = '../index.html';
}
document.addEventListener('DOMContentLoaded', async () => {
    const jobsContainer = document.getElementById('jobsContainer');

    async function fetchJobs() {
        try {
            const response = await fetch('/jobs');
            const jobs = await response.json();

            jobsContainer.innerHTML = '';
            jobs.forEach(job => {
                const jobDiv = document.createElement('div');
                jobDiv.classList.add(job.type === 'job' ? 'job-listing' : 'internship-listing');
                
                const jobLink = document.createElement('a');
                jobLink.href = `../jobs/${job.filename}`;
                jobLink.textContent = `${job.position} @ ${job.company}`;

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.addEventListener('click', async () => {
                    try {
                        const response = await fetch(`/jobs/${job.id}`, {
                            method: 'DELETE'
                        });
                        if (response.ok) {
                            fetchJobs();
                        } else {
                            console.error('Failed to delete job');
                        }
                    } catch (error) {
                        console.error('Error deleting job:', error);
                    }
                });

                jobDiv.appendChild(jobLink);
                jobDiv.appendChild(deleteButton);
                jobsContainer.appendChild(jobDiv);
            });
        } catch (error) {
            console.error('Error fetching jobs:', error);
        }
    }

    fetchJobs();
});